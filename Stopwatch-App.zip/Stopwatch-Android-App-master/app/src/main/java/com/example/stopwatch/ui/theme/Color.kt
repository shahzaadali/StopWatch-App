package com.example.stopwatch.ui.theme

import androidx.compose.ui.graphics.Color

val Purple200 = Color(0xFF167AF6)
val Purple500 = Color(0xFF167AF6)
val Purple700 = Color(0xFF167AF6)
val Teal200 = Color(0xFF167AF6)

val Blue = Color(0xFF167AF6)
val Red = Color(0xFFe93560)
val Dark = Color(0xFF0E0D1D)
val Light = Color(0xFF17162B)